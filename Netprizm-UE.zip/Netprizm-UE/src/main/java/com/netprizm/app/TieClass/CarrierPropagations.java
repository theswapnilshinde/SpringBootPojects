package com.netprizm.app.TieClass;
//
//import java.util.List;
//
//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//import lombok.Data;
//
//@Entity
//@Table(name ="carrierPropagations")
//@Data
//public class CarrierPropagations {
//	
//	private int carrierPropagationId ;
//	private int configNodeCarrierId40;
//	private int configTileId;
//	private String render;
//}
