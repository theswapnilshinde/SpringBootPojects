package com.netprizm.app.TieClass;

import java.util.List;

import com.netprizm.app.entity.Tower;

import lombok.Data;

@Data
public class TemplateRequestDto {
	private int	templateId ;
	private String name   ;
	private List<Tower> towers;
}
