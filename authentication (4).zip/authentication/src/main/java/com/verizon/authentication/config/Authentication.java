package com.verizon.authentication.config;

import org.springframework.context.annotation.Configuration;

import javax.naming.AuthenticationException;
import javax.naming.AuthenticationNotSupportedException;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import java.util.Hashtable;

@Configuration
/*Check The User is valid or not*/
public class Authentication {

    // boolean function to test user and password
    public boolean userVerify(String uname, String passwd) throws Exception{
        /*
         * System.out.println(uname); System.out.println(passwd);
         */
        boolean userVerify = true;
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, "ldap://localhost:2389/dc=springframework,dc=org");
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, "uid=bob,ou=people,dc=springframework,dc=org");
        env.put(Context.SECURITY_CREDENTIALS, "bobspassword");

        try {
            DirContext ctx = new InitialDirContext(env);
            System.out.println("connected");
            System.out.println(ctx.getEnvironment());
            userVerify = false;
            ctx.close();

        } catch (AuthenticationNotSupportedException ex) {
            System.out.println("The authentication is not supported by the server");
        } catch (AuthenticationException ex) {
            System.out.println("incorrect password or username");
            System.out.println(ex.getLocalizedMessage());
            throw new AuthenticationException();
        } catch (NamingException ex) {
            System.out.println("error when trying to create the context");
        }
        return userVerify;
    }
    
}
