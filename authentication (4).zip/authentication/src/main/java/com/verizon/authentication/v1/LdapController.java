/*
package com.verizon.authentication.v1;

import com.verizon.authentication.v1.Request.JwtRequest;
import com.verizon.authentication.v1.Request.LdapRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class LdapController {

    @PostMapping("/api")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody userDTO userDtO) throws Exception {

    }
*/
