package com.netprizm.ccss.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.netprizm.ccss.models.Imsi;

@Service
public interface ImsiService {

	Imsi saveImsi(Imsi imsi);
	
//	Imsi updateImsi(Imsi imsi);
//	Imsi saveImsi(Integer imsiid);
//	Imsi getSingleImsi(Integer imsiid);
//	Imsi deleteImsi(Integer imsiid);
//	List<Imsi> getallImsi();

}
