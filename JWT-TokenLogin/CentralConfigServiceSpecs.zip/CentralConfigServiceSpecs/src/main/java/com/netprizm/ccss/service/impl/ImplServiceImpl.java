package com.netprizm.ccss.service.impl;

import java.util.Date;
import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netprizm.ccss.models.Imsi;
import com.netprizm.ccss.repository.ImsiRepositary;
import com.netprizm.ccss.service.ImsiService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ImplServiceImpl  implements ImsiService{

   @Autowired
	private ImsiRepositary imsiRepositary;

	@Override
	public Imsi saveImsi(Imsi imsi) {
	//	Imsi  imsi2= this.saveImsi(imsi);
		Imsi imsi2 = new Imsi();
		
		imsi2.setCoreip(imsi.getCoreip());
		imsi2.setIsreserved(true);
		imsi2.setEnvironment(imsi.getEnvironment());
		imsi2.setImsiid(imsi.getImsiid());
		imsi2.setImsi(imsi.getImsi());
		imsi2.setRunid(imsi.getRunid());
		//imsi2.setReservationtime(new Date());
		
	//	imsi2= imsiRepositary.save(imsi);
	//	System.out.println("***********"+ imsi2 +"**********" );
		findReserved();
		return imsi2;
	}
   
	public Boolean findReserved () {
		List<Imsi> listOfImsi =  imsiRepositary.findByIsreserved(true);
		log.info("listOfImsi::{}",listOfImsi);
	//	imsiRepositary.updateImsi("evv2",true,3,11);
		return null;
		
//	//	Boolean imsi3=	imsiRepositary.findByIsreserved(true);
//		System.out.println("*******"+imsi3+"******");
//		return imsi3;
		
	}

	public Imsi reserve(Imsi imsi) {
		
		
		String envv= imsi.getEnvironment();
		Boolean flag= imsi.isIsreserved();
//		int runid= 200;//imsi.getRunid();
		int imssid= 14;
		//reserveList();
		
		findReserved();
	//	imsiRepositary.updateImsi(envv,flag,runid,imssid);
		return imsi;
	}
	
//	public Imsi count ()
//	{
//		
//	//	List<Imsi> listOfImsi =  imsiRepositary.findByIsreserved(false);
//	//
//	//	int i = listOfImsi.size();
////		System.out.println("$$$$$$$$$$$"+ i +"$$$$$$$$$$$$$");
////		return null;
//	}
	
   // public List<Imsi> reserveList(Imsi imsi)
	public void reserveList(){
    	 
    	 
    	 List<Imsi> listOfImsi =  imsiRepositary.findByIsreserved(false);
    	
		
		
		
	}

	public Imsi release(Imsi imsi) {
		String environment= imsi.getEnvironment();
		Boolean flag=false;
		int runid= imsi.getRunid();
	//	int imssid= 14;
		
//		List<Imsi> listOfImsi =  imsiRepositary.findByruid();
//		log.info("listOfImsi::{}",listOfImsi);
		
		
		Imsi imsi2=	imsiRepositary.findByrunid(runid);
		Imsi imsi3=	imsiRepositary.findByenvironment(environment);
		
		System.out.println(imsi2);
		System.out.println(imsi3);
		
		
		int imssid1=imsi3.getImsiid();
//		
//		  List<Imsi> listOfImsi = imsiRepositary.findByIsreserved(false);
//		  log.info("listOfImsi::{}",listOfImsi);
//		 
	
		String envv = null;
		Integer runid1 = null;
		imsiRepositary.updateImsi(envv,flag,runid1,imssid1);
		return imsi3;
	}
	
}
