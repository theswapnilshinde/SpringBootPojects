package com.netprizm.ccss.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.netprizm.ccss.models.Template;

public interface TemplateRepositary extends JpaRepository<Template, Integer> {

}
