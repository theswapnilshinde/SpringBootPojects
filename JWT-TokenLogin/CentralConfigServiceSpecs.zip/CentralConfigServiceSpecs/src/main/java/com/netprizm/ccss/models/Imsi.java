package com.netprizm.ccss.models;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Entity
@Table(name="imsi")
@Data

public class Imsi {
	@Id
	private int imsiid;
	private String coreip;
	// @Convert("booleanToInteger")
	private boolean isreserved;
	private String environment;
//	@Temporal(TemporalType.TIMESTAMP)
//	@Column(nullable = false)
	//@PreUpdate
	//@PrePersist 
	//private Date reservationtime = new Date();
	private  LocalDateTime  reservationtime = LocalDateTime.now();
	private String imsi;
	private int runid;

}
