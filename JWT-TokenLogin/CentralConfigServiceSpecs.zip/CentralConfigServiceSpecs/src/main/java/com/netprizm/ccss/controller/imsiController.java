package com.netprizm.ccss.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netprizm.ccss.models.Imsi;
import com.netprizm.ccss.service.impl.ImplServiceImpl;



@CrossOrigin
@RestController
@RequestMapping("/central-cfg-service")
public class imsiController {

	@Autowired
	private ImplServiceImpl imsiService ;

	@PostMapping("/add2")
	public ResponseEntity<Imsi> createUser( @RequestBody Imsi imsi)
	{
		Imsi  imsi2= this.imsiService.saveImsi(imsi);

		return new ResponseEntity<>(imsi2,HttpStatus.CREATED);

	}
	///central-cfg-service/api/v1/config/imsi/reserve

	
	@PostMapping("/api/v1/config/imsi/reserve")
	public ResponseEntity<Imsi> reserve( @RequestBody Imsi imsi)
	{
		Imsi  imsi2= this.imsiService.reserve(imsi);

		return new ResponseEntity<>(imsi2,HttpStatus.CREATED);

	}
	
	@PostMapping("/api/v1/config/imsi/release")
	public ResponseEntity<Imsi> release( @RequestBody Imsi imsi)
	{
		Imsi  imsi2= this.imsiService.release(imsi);

		return new ResponseEntity<>(imsi2,HttpStatus.CREATED);

	}

}
