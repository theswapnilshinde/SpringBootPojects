package com.netprizm.ccss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentralConfigServiceSpecsApplicationTests {

	@Test
	void contextLoads() {
	}

}
