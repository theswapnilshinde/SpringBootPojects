package com.netprizm.ccss.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netprizm.ccss.models.Imsi;
import com.netprizm.ccss.service.impl.ImplServiceImpl;



@CrossOrigin
@RestController
@RequestMapping("/central-cfg-service")
public class ImsiController {

	@Autowired
	private ImplServiceImpl imsiService ;



	@PostMapping("/api/v1/config/imsi/reserve")
	public ResponseEntity<Imsi> reserve( @RequestBody Imsi imsi)
	{
		String  imsi2= this.imsiService.reserve(imsi);

		if(imsi2 =="success")
		{
			return new ResponseEntity<>(HttpStatus.OK);
		}
		else
		{
			if(imsi2=="not reseved")
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			else {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		}


	}

	@PostMapping("/api/v1/config/imsi/release")
	public ResponseEntity<Imsi> release( @RequestBody Imsi imsi)
	{
		String  imsi2= this.imsiService.release(imsi);

		if(imsi2 =="success")
		{
			return new ResponseEntity<>(HttpStatus.OK);
		}
		else
		{
			if(imsi2=="notrelease")
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			else {
				
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		}

	}

	//	@PostMapping("/add2")
	//	public ResponseEntity<Imsi> createUser( @RequestBody Imsi imsi)
	//	{
	//		Imsi  imsi2= this.imsiService.saveImsi(imsi);
	//
	//		return new ResponseEntity<>(imsi2,HttpStatus.CREATED);
	//
	//	}
	//	///central-cfg-service/api/v1/config/imsi/reserve


}
