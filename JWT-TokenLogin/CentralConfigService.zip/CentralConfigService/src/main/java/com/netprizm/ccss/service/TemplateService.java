package com.netprizm.ccss.service;

public interface TemplateService {

}
