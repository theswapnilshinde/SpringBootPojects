package com.netprizm.app.allexceptions;

public class APIException extends RuntimeException{

	
	private static final long serialVersionUID = 1L;

	public APIException() {
		super();
		
	}

	
	

}
